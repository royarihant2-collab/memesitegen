const imageInput = document.getElementById('imageInput');
const topText = document.getElementById('topText');
const bottomText = document.getElementById('bottomText');
const generateBtn = document.getElementById('generateBtn');
const canvas = document.getElementById('memeCanvas');
const ctx = canvas.getContext('2d');

let img = new Image();

imageInput.addEventListener('change', function(e) {
  const file = e.target.files[0];
  const reader = new FileReader();
  reader.onload = function(event) {
    img.src = event.target.result;
  }
  reader.readAsDataURL(file);
});

img.onload = function() {
  canvas.width = img.width;
  canvas.height = img.height;
  drawMeme();
};

generateBtn.addEventListener('click', drawMeme);

function drawMeme() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

  ctx.font = "50px Impact";
  ctx.fillStyle = "white";
  ctx.strokeStyle = "black";
  ctx.lineWidth = 3;
  ctx.textAlign = "center";

  ctx.fillText(topText.value.toUpperCase(), canvas.width / 2, 60);
  ctx.strokeText(topText.value.toUpperCase(), canvas.width / 2, 60);

  ctx.fillText(bottomText.value.toUpperCase(), canvas.width / 2, canvas.height - 20);
  ctx.strokeText(bottomText.value.toUpperCase(), canvas.width / 2, canvas.height - 20);
}